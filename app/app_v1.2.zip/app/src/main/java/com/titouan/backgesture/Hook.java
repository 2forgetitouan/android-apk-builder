package io.github.backgestureheight;

import android.content.Context;
import android.os.Build;
import android.provider.Settings;
import android.view.InputEvent;
import android.view.MotionEvent;

import java.lang.reflect.Method;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public final class Hook implements IXposedHookLoadPackage {
    private static final String TAG = "BackGestureHeight";
    private static final String KEY = "gesture_back_exclude_top";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) throws Throwable {
        if (!"com.android.systemui".equals(lp.packageName)) return;

        try {
            Class<?> edgeClass = XposedHelpers.findClass(
                    "com.android.systemui.navigationbar.gestural.EdgeBackGestureHandler",
                    lp.classLoader);

            // Android 14/15: isWithinTouchRegion(int, int) on EdgeBackGestureHandler
            Method target = findTouchRegionMethod(edgeClass);

            if (target == null) {
                // Android 16: logic moved to DisplayBackGestureHandlerImpl
                try {
                    Class<?> implClass = XposedHelpers.findClass(
                            "com.android.systemui.navigationbar.gestural.DisplayBackGestureHandlerImpl",
                            lp.classLoader);
                    target = findTouchRegionMethod(implClass);
                } catch (Throwable ignored) {}
            }

            if (target != null) {
                installTouchRegionHook(target);
                return;
            }

            // Android 16 fallback: isWithinTouchRegion gone entirely — intercept at onInputEvent
            XposedBridge.log(TAG + ": isWithinTouchRegion not found, hooking onInputEvent");
            installInputEventHook(edgeClass);

        } catch (Throwable t) {
            XposedBridge.log(TAG + ": hook installation failed: " + t);
        }
    }

    private void installTouchRegionHook(Method target) {
        XposedBridge.hookMethod(target, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                try {
                    Context ctx = getContext(param.thisObject);
                    if (ctx == null) return;

                    int percent = getPercent(ctx);
                    if (percent == 0) return;

                    int displayHeight = getDisplayHeight(param.thisObject, ctx);
                    if (displayHeight <= 0) return;

                    // args: [0]=x, [1]=y
                    int y = (Integer) param.args[1];
                    if (y < displayHeight * percent / 100) {
                        param.setResult(false);
                    }
                } catch (Throwable t) {
                    XposedBridge.log(TAG + ": hook error: " + t);
                }
            }
        });
        XposedBridge.log(TAG + ": hooked "
                + target.getDeclaringClass().getSimpleName() + "." + target.getName());
    }

    private void installInputEventHook(Class<?> clazz) {
        // For Android 16: suppress DOWN events that land in the excluded top zone.
        // onInputEvent is void — returning early (setResult(null)) prevents gesture tracking.
        XposedHelpers.findAndHookMethod(clazz, "onInputEvent", InputEvent.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                try {
                    InputEvent ev = (InputEvent) param.args[0];
                    if (!(ev instanceof MotionEvent)) return;
                    MotionEvent me = (MotionEvent) ev;
                    if (me.getActionMasked() != MotionEvent.ACTION_DOWN) return;

                    Context ctx = getContext(param.thisObject);
                    if (ctx == null) return;

                    int percent = getPercent(ctx);
                    if (percent == 0) return;

                    int displayHeight = getDisplayHeight(param.thisObject, ctx);
                    if (displayHeight <= 0) return;

                    if (me.getY() < displayHeight * percent / 100f) {
                        param.setResult(null);
                    }
                } catch (Throwable t) {
                    XposedBridge.log(TAG + ": hook error: " + t);
                }
            }
        });
        XposedBridge.log(TAG + ": hooked onInputEvent (Android 16)");
    }

    private static Method findTouchRegionMethod(Class<?> clazz) {
        try {
            return clazz.getDeclaredMethod("isWithinTouchRegion", int.class, int.class);
        } catch (NoSuchMethodException ignored) {}

        for (Method m : clazz.getDeclaredMethods()) {
            if (!m.getName().contains("TouchRegion")) continue;
            if (m.getReturnType() != boolean.class) continue;
            int intCount = 0;
            for (Class<?> p : m.getParameterTypes()) if (p == int.class) intCount++;
            if (intCount >= 2) return m;
        }
        return null;
    }

    private static Context getContext(Object obj) {
        for (String field : new String[]{"mContext", "mBaseContext"}) {
            try {
                Object v = XposedHelpers.getObjectField(obj, field);
                if (v instanceof Context) return (Context) v;
            } catch (Throwable ignored) {}
        }
        return null;
    }

    private static int getPercent(Context ctx) {
        int p = Settings.Secure.getInt(ctx.getContentResolver(), KEY, 0);
        return Math.max(0, Math.min(50, p));
    }

    private static int getDisplayHeight(Object handler, Context ctx) {
        try {
            android.graphics.Point p = (android.graphics.Point)
                    XposedHelpers.getObjectField(handler, "mDisplaySize");
            if (p != null && p.y > 0) return p.y;
        } catch (Throwable ignored) {}

        try {
            android.view.WindowManager wm = (android.view.WindowManager)
                    ctx.getSystemService(Context.WINDOW_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                return wm.getCurrentWindowMetrics().getBounds().height();
            } else {
                android.graphics.Point size = new android.graphics.Point();
                //noinspection deprecation
                wm.getDefaultDisplay().getSize(size);
                return size.y;
            }
        } catch (Throwable ignored) {}

        return 0;
    }
}
