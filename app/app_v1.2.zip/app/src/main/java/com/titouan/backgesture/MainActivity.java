package io.github.backgestureheight;

import android.app.Activity;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    SeekBar seek;
    TextView value;

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(48, 48, 48, 48);

        // Absorb system bar insets so the UI isn't hidden under the status/nav bar.
        // Android 15+ forces edge-to-edge on targetSdk 35, making this mandatory.
        r.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = insets.getSystemWindowInsetTop();
            int bottom = insets.getSystemWindowInsetBottom();
            v.setPadding(48, 48 + top, 48, 48 + bottom);
            return insets.consumeSystemWindowInsets();
        });

        TextView t = new TextView(this);
        t.setText("Back Gesture - zone haute exclue  v1.2");
        t.setTextSize(22);
        r.addView(t);

        value = new TextView(this);
        value.setTextSize(18);
        r.addView(value);

        seek = new SeekBar(this);
        seek.setMax(50);
        r.addView(seek);

        Button a = new Button(this);
        a.setText("Appliquer et redémarrer SystemUI");
        r.addView(a);

        TextView info = new TextView(this);
        info.setText("0 % = aucun changement\n"
                + "30 % = les 30 % supérieurs sont exclus\n"
                + "50 % = moitié supérieure exclue\n\n"
                + "Le hook agit uniquement dans SystemUI.");
        r.addView(info);

        int cur = 0;
        try {
            cur = Settings.Secure.getInt(getContentResolver(), "gesture_back_exclude_top", 0);
        } catch (Exception ignored) {}
        seek.setProgress(Math.max(0, Math.min(50, cur)));
        update();

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean f) { update(); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });

        a.setOnClickListener(v -> {
            int p = seek.getProgress();
            try {
                Process su = Runtime.getRuntime().exec(new String[]{"su"});
                java.io.DataOutputStream d = new java.io.DataOutputStream(su.getOutputStream());
                d.writeBytes("settings put secure gesture_back_exclude_top " + p
                        + "\nkillall com.android.systemui\nexit\n");
                d.flush();
                su.waitFor();
                Toast.makeText(this, "Appliqué : " + p + " %", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Root requis : " + e, Toast.LENGTH_LONG).show();
            }
        });

        setContentView(r);
    }

    void update() {
        value.setText(seek.getProgress() + " %");
    }
}
