package com.titouan.backgesture;

import android.content.Context;
import android.os.Build;
import android.provider.Settings;

import java.lang.reflect.Method;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public final class Hook implements IXposedHookLoadPackage {
    private static final String TAG = "BackGestureHeight";
    private static final String KEY = "gesture_back_exclude_top";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) throws Throwable {
        if (!"com.android.systemui".equals(lp.packageName)) return;

        try {
            Class<?> clazz = XposedHelpers.findClass(
                    "com.android.systemui.navigationbar.gestural.EdgeBackGestureHandler",
                    lp.classLoader);

            Method target = findTouchRegionMethod(clazz);
            if (target == null) {
                XposedBridge.log(TAG + ": no touch-region method found; available methods:");
                for (Method m : clazz.getDeclaredMethods())
                    XposedBridge.log(TAG + ":   " + m.toString());
                return;
            }

            XposedBridge.hookMethod(target, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    try {
                        Context ctx = (Context) XposedHelpers.getObjectField(
                                param.thisObject, "mContext");

                        int percent = Settings.Secure.getInt(
                                ctx.getContentResolver(), KEY, 0);
                        percent = Math.max(0, Math.min(50, percent));
                        if (percent == 0) return;

                        int displayHeight = getDisplayHeight(param.thisObject, ctx);
                        if (displayHeight <= 0) return;

                        // args[0]=x, args[1]=y (consistent across known signatures)
                        int y = (Integer) param.args[1];
                        if (y < displayHeight * percent / 100) {
                            param.setResult(false);
                        }
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + ": hook error: " + t);
                    }
                }
            });

            XposedBridge.log(TAG + ": hooked " + target.getName() + " successfully");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": hook installation failed: " + t);
        }
    }

    // Try exact Android 14/15 signature first, then scan for any (x,y)->boolean variant.
    private static Method findTouchRegionMethod(Class<?> clazz) {
        try {
            return clazz.getDeclaredMethod("isWithinTouchRegion", int.class, int.class);
        } catch (NoSuchMethodException ignored) {}

        for (Method m : clazz.getDeclaredMethods()) {
            if (!m.getName().contains("TouchRegion")) continue;
            if (m.getReturnType() != boolean.class) continue;
            int intCount = 0;
            for (Class<?> p : m.getParameterTypes()) if (p == int.class) intCount++;
            if (intCount >= 2) return m;
        }
        return null;
    }

    private static int getDisplayHeight(Object handler, Context ctx) {
        // Try the cached field first (present in Android 14/15)
        try {
            android.graphics.Point p = (android.graphics.Point)
                    XposedHelpers.getObjectField(handler, "mDisplaySize");
            if (p != null && p.y > 0) return p.y;
        } catch (Throwable ignored) {}

        // Fallback: ask WindowManager directly (API 30+)
        try {
            android.view.WindowManager wm = (android.view.WindowManager)
                    ctx.getSystemService(Context.WINDOW_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                return wm.getCurrentWindowMetrics().getBounds().height();
            } else {
                android.graphics.Point size = new android.graphics.Point();
                //noinspection deprecation
                wm.getDefaultDisplay().getSize(size);
                return size.y;
            }
        } catch (Throwable ignored) {}

        return 0;
    }
}
